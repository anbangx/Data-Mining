		% set parameter K if desired
		function obj=setK(obj, K)
			obj.K = K;
		end
