function wts = getWeights(obj)
% wts = getWeights(obj) : return the d+1 weights of the linear classifier

wts = obj.wts;
