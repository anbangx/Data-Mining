function obj = setWeights(obj,wts)
% obj = setWeights(obj,wts) : set the d+1 weights of the linear classifier

obj.theta = wts;
