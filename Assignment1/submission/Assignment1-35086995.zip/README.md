Data-Mining
===========

CS277 course project

For assignment1, I use python pandas as API. In order to run my python scripy, please download pandas from http://pandas.pydata.org/.
Additionally, you need to figure folder and its childrent folders in order to run the program.

And the following command lines:
chmod +x assignment1.py
./assignment1.py
